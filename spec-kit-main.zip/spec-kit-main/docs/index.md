<div class="landing-hero">

<img class="landing-hero-logo" src="images/spec-kit-logo.webp" alt="" width="120" height="120">

# GitHub Spec Kit

**Build with a spec, fix a bug, or assess an idea — with your coding agent.**

Spec Kit gives your coding agent structured processes that keep intent and evidence ahead of implementation. Start with Spec-Driven Development (SDD), bug fixing, or idea assessment. Run a process step by step, automate it, or [shape one of your own](guides/customization.md) — including processes beyond software development.

<a href="installation.md" class="btn btn-primary btn-lg">Install Spec Kit</a>&nbsp;
<a href="#choose-your-process" class="btn btn-outline-primary btn-lg">Choose your process</a>

</div>

---

## Choose your process

| What you need | Start here | What you get |
| --- | --- | --- |
| Build a feature or application | [Spec-Driven Development](quickstart.md) | A specification carried through planning, implementation, and convergence |
| Diagnose and repair broken behavior | [Bug fixing](guides/bugfix.md) | An assessed cause, scoped fix, and recorded verification |
| Decide whether an idea deserves investment | [Idea assessment](guides/assessment.md) | An evidence-backed go, clarify, or stop decision |

These are independent entry points, not mandatory phases. SDD ships in core.
Bug fixing and assessment are bundled, opt-in extensions. Assessment can stand
alone; a decision to proceed does not automatically start implementation.

See [how the Spec Kit project runs its agentic SDLC](guides/agentic-sdlc.md)
and where it uses Spec Kit itself.

Adding Spec Kit to an established codebase? Start with the
[existing-project guide](guides/existing-projects.md).

---

<div class="pillar-grid">

<div class="pillar-card">

### Spec-driven by default

The core SDD process ships ready to use: **Specify → Plan → Tasks → Implement → Converge**.

Define what to build before building it. Rich templates, quality checklists, and cross-artifact analysis come out of the box. Each phase produces a Markdown artifact that feeds the next — giving your AI coding agent structured context instead of ad-hoc prompts.

<a href="quickstart.md" class="pillar-link">Walk through the workflow →</a>

</div>

<div class="pillar-card">

### Use any coding agent

<span class="pillar-stat">38 integrations</span> — Copilot, Gemini, Codex, Kilo Code, Zed, Claude, Forge, Kiro, and more. Switch freely between agents with a single command. No lock-in.

Run `specify init` with your agent of choice and Spec Kit sets up the right command files and directory structures automatically. If your agent isn't listed, the `generic` integration is an escape hatch for any tool.

<a href="reference/integrations.md" class="pillar-link">See all integrations →</a>

</div>

<div class="pillar-card">

### Make it your own

<span class="pillar-stat">157 community extensions</span> (90+ authors), <span class="pillar-stat">33 presets</span>, and growing. Tune the core process with presets, extend it with extensions, orchestrate it with workflows, and package it all up as bundles you can share — or replace the process entirely. The process itself lives in these building blocks, so you're never locked to SDD, or even to software.

Including entirely different processes:

- **AIDE** — 7-step AI-driven engineering lifecycle
- **Canon** — baseline-driven workflows (spec-first, code-first, spec-drift)
- **Product Forge** — product-management-oriented SDD
- **FX→.NET** — end-to-end .NET Framework migration across 7 phases
- **MAQA** — multi-agent orchestration with quality assurance gates
- **Fiction Book Writing** — novels and long-form fiction, from story bible to submission

<a href="reference/presets.md" class="pillar-link">Presets →</a>&nbsp;&nbsp;
<a href="reference/extensions.md" class="pillar-link">Extensions →</a>&nbsp;&nbsp;
<a href="reference/workflows.md" class="pillar-link">Workflows →</a>&nbsp;&nbsp;
<a href="reference/bundles.md" class="pillar-link">Bundles →</a>

</div>

<div class="pillar-card">

### Integrate into your organization

Works offline, behind firewalls, and on **Windows, macOS, and Linux**. Host your own catalogs to curate what integrations, extensions, presets, workflows, and bundles your organization discovers and recommends.

Community extensions like CI Guard and Architecture Guard add compliance gates and governance that fit the way your team already works.

<a href="install/air-gapped.md" class="pillar-link">Enterprise / Air-Gapped →</a>&nbsp;&nbsp;
<a href="reference/overview.md" class="pillar-link">Reference →</a>

</div>

</div>

---

<div class="community-section">

## Built by the community

**270+ contributors** power the Spec Kit ecosystem — from core integrations to entirely new processes. Anyone can create and publish an extension, preset, or workflow.

<div class="stats-grid">
  <div class="stat-item">
    <span class="stat-number">130K+</span>
    <span class="stat-label">GitHub stars</span>
  </div>
  <div class="stat-item">
    <span class="stat-number">270+</span>
    <span class="stat-label">Contributors</span>
  </div>
  <div class="stat-item">
    <span class="stat-number">38</span>
    <span class="stat-label">Integrations</span>
  </div>
  <div class="stat-item">
    <span class="stat-number">157</span>
    <span class="stat-label">Extensions</span>
  </div>
  <div class="stat-item">
    <span class="stat-number">33</span>
    <span class="stat-label">Presets</span>
  </div>
  <div class="stat-item">
    <span class="stat-number">7</span>
    <span class="stat-label">Friends projects</span>
  </div>
</div>

<a href="community/presets.md">Presets</a> · <a href="community/walkthroughs.md">Walkthroughs</a> · <a href="community/friends.md">Friends</a>

</div>

---

## Explore the docs

<div class="nav-cards">
  <a href="guides/agentic-sdlc.md" class="nav-card">
    <strong>Spec Kit's Agentic SDLC</strong>
    <span>How this project assesses, builds, tests, ships, and repairs changes</span>
  </a>
  <a href="quickstart.md" class="nav-card">
    <strong>Spec-Driven Development</strong>
    <span>Define, plan, implement, and converge on a feature</span>
  </a>
  <a href="guides/bugfix.md" class="nav-card">
    <strong>Bug Fixing</strong>
    <span>Assess the cause, apply a scoped fix, and verify the result</span>
  </a>
  <a href="guides/assessment.md" class="nav-card">
    <strong>Idea Assessment</strong>
    <span>Research an idea and decide whether it deserves investment</span>
  </a>
  <a href="guides/customization.md" class="nav-card">
    <strong>Customize Spec Kit</strong>
    <span>Adapt a process, add capabilities, or package a role-based setup</span>
  </a>
  <a href="guides/existing-projects.md" class="nav-card">
    <strong>Existing Projects</strong>
    <span>Adopt Spec Kit safely in an established codebase</span>
  </a>
  <a href="upgrade.md" class="nav-card">
    <strong>Upgrade</strong>
    <span>Keep an existing Spec Kit project current across releases</span>
  </a>
  <a href="reference/overview.md" class="nav-card">
    <strong>Reference</strong>
    <span>Core commands, integrations, extensions, presets, and workflows</span>
  </a>
  <a href="community/overview.md" class="nav-card">
    <strong>Community</strong>
    <span>Extensions, presets, walkthroughs, and friend projects</span>
  </a>
  <a href="local-development.md" class="nav-card">
    <strong>Development</strong>
    <span>Contribute to Spec Kit</span>
  </a>
  <a href="concepts/sdd.md" class="nav-card">
    <strong>What is SDD?</strong>
    <span>The philosophy behind Spec-Driven Development</span>
  </a>
  <a href="history.md" class="nav-card">
    <strong>History</strong>
    <span>How Spec Kit grew from its SDD foundation into an extensible process harness</span>
  </a>
</div>

---

<div class="footer-cta">

```bash
uv tool install specify-cli
specify init my-project --integration copilot
```

Ready to start? [Choose your process](#choose-your-process).

</div>

<p class="text-end small text-body-secondary">Last updated: September 28, 2026</p>
